import { useState, useEffect } from "react";
import { getUrls } from "../api/url";
import ShortenForm from "../components/ShortenForm";
import UrlTable from "../components/UrlTables";

function Dashboard({ user }) {
  const [urls, setUrls] = useState([]);

  useEffect(() => {
    fetchUrls();
  }, []);

  async function fetchUrls() {
    try {
      const res = await getUrls(user.id);
      setUrls(res.data);
    } catch (err) {
      console.log(err);
    }
  }

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>Welcome, {user.name} 👋</h2>
      <ShortenForm user={user} onShorten={fetchUrls} />
      <UrlTable urls={urls} />
    </div>
  );
}

const styles = {
  container: {
    minHeight: "100vh",
    background: "linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.8))",
    color: "white",
    padding: "40px 80px",
  },
  heading: {
    fontSize: "2rem",
    marginBottom: "30px",
  },
};

export default Dashboard;