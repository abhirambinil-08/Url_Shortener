// import "../style/Hero.css";

// function Hero() {
//   return (
//     <section className="hero">
//       <div className="hero-content">
//         <h1 className="hero-title">Shorter your url, </h1>
//         <h1 className="hero-title">Not your Code... </h1>

//         <h3 className="hero-price">
//           Ready to simplify your links? Enter your email to get started.
//         </h3>

//         <div className="hero-form">
//           <input
//             type="email"
//             id="emailInput"
//             name="export async function ()={
//                const let -=//             className="hero-input"
//           />

//           <button className="hero-btn">Login / Sign-up</button>
//         </div>
//       </div>
//     </section>
//   );
// }

// export default Hero;
