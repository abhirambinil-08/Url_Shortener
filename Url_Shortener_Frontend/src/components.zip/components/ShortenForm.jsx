import { useState } from "react";
import { shortenUrl } from "../api/url";

function ShortenForm({ user, onShorten }) {
  const [longUrl, setLongUrl] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleShorten() {
    if (!longUrl) return alert("Enter a URL first");
    try {
      setLoading(true);
      const res = await shortenUrl(user.id, longUrl);
      alert("Short URL: " + res.data.shortUrl);
      setLongUrl("");
      onShorten();
    } catch (err) {
      alert(err.response?.data?.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={styles.card}>
      <h4 style={styles.label}>Shorten a new URL</h4>
      <div style={styles.row}>
        <input
          type="text"
          placeholder="Paste your long URL here..."
          value={longUrl}
          onChange={(e) => setLongUrl(e.target.value)}
          style={styles.input}
        />
        <button onClick={handleShorten} style={styles.btn} disabled={loading}>
          {loading ? "Shortening..." : "Shorten"}
        </button>
      </div>
    </div>
  );
}

const styles = {
  card: {
    background: "rgba(255,255,255,0.05)",
    borderRadius: "10px",
    padding: "25px",
    marginBottom: "30px",
  },
  label: {
    marginBottom: "15px",
    fontSize: "1.1rem",
  },
  row: {
    display: "flex",
    gap: "15px",
  },
  input: {
    flex: 1,
    padding: "14px",
    borderRadius: "5px",
    border: "1px solid white",
    background: "transparent",
    color: "white",
    fontSize: "1rem",
    outline: "none",
  },
  btn: {
    padding: "14px 35px",
    background: "#e50914",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "1rem",
    fontWeight: "bold",
  },
};

export default ShortenForm;