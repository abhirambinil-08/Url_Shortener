function UrlRow({ url }) {
  return (
    <tr>
      <td style={styles.td}>
        <a
          href={url.long_url}
          target="_blank"
          rel="noreferrer"
          style={styles.link}
        >
          {url.long_url.length > 40
            ? url.long_url.substring(0, 40) + "..."
            : url.long_url}
        </a>
      </td>
      <td style={styles.td}>
        <a
          href={`http://localhost:3000/${url.short_code}`}
          target="_blank"
          rel="noreferrer"
          style={{ ...styles.link, color: "#e50914" }}
        >
          localhost:3000/{url.short_code}
        </a>
      </td>
      <td style={styles.td}>{url.click_count}</td>
    </tr>
  );
}

const styles = {
  td: {
    padding: "12px",
    borderBottom: "1px solid rgba(255,255,255,0.1)",
  },
  link: {
    color: "white",
    textDecoration: "none",
  },
};

export default UrlRow;
