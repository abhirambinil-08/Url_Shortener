import UrlRow from "../components/UrlRow";

function UrlTable({ urls }) {
  return (
    <div style={styles.card}>
      <h4 style={styles.label}>Your URLs</h4>
      {urls.length === 0 ? (
        <p style={{ color: "#888" }}>No URLs yet. Create one above!</p>
      ) : (
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>Original URL</th>
              <th style={styles.th}>Short URL</th>
              <th style={styles.th}>Clicks</th>
            </tr>
          </thead>
          <tbody>
            {urls.map((url) => (
              <UrlRow key={url.id} url={url} />
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

const styles = {
  card: {
    background: "rgba(255,255,255,0.05)",
    borderRadius: "10px",
    padding: "25px",
    marginBottom: "30px",
  },
  label: {
    marginBottom: "15px",
    fontSize: "1.1rem",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
  },
  th: {
    textAlign: "left",
    padding: "12px",
    borderBottom: "1px solid rgba(255,255,255,0.2)",
    color: "#aaa",
  },
};

export default UrlTable;